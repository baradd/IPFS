const fetch = require('node-fetch');
const jsdom = require('jsdom');
const { JSDOM } = jsdom;
const rootDir = require('app-root-dir').get();
const path = require('path');
const fs = require('fs');
let getPaintext = (async () => {
  const response = await fetch(
    'https://ipfs.io/ipfs/bafybeih3yul3qssgibmudfdfgevbi5bkqpg7qign7vlw57fn3h34vpcti4'
  );
  const body = await response.text();
  const dom = new JSDOM(body);
  let jsonFiles = dom.window.document.querySelectorAll('.ipfs-hash');
  for (let index = 1; index < jsonFiles.length; index++) {
    const element = jsonFiles[index];
    let getJson = await fetch(`https://ipfs.io/${element}`);
    let jsonContent = await getJson.json();
    fs.writeFileSync(
      path.join(rootDir, 'files', `${index}.json`),
      JSON.stringify(jsonContent),
      {
        encoding: 'utf-8',
      }
    );
    // console.log(element);
  }
  console.log(jsonFiles.length);
})();
